	//version 2
	function openTimeoutDialog(url,width,height){
			return private_openModalDialog(url,width,height);
	}

	function private_openModalDialog(url,width,height){
	
			var div = document.createElement('<div style="position: absolute;z-index: 200;'+
			'top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;'+
			'+filter: alpha(opacity=40);background-color:transparent !important;'+
			'background-color: lightgrey;" />');
			if(document.body){
				var ourdiv = document.body.appendChild(div);
			}
	
		    showx = (screen.availWidth -width)/2; // + deltaX;
		    showy = (screen.availHeight-height)/2; // + deltaY;
			var par = []; 
			par['url'] = url;
			par['parentwindow'] = window;		
		   	var s1 = "dialogWidth:"+width+"px; dialogHeight:"+height+"px; dialogLeft:"+showx+"px; dialogTop:"+
		   			showy+"px;  help:no;directories:yes;scrollbars:no;Resizable:yes;status:no;";
		    retval = window.showModalDialog(url,
		    par,s1
		    );
		   if(document.body){
				document.body.removeChild(ourdiv);
			}
			
			return retval;
	}