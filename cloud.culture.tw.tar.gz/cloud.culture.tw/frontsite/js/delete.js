function doNewDelete(url){
 	if(confirm('確定刪除資料?')){
 			window.location = url;
	}
}

//返回多選按鈕被選擇的值的數組
function checkSelect(checkboxName) {
    var checkboxName=document.getElementsByName(checkboxName);
    var retArr = new Array();
    var lastElement = 0;
	if(checkboxName[0]) { // if the checkbox is an array
		 for (var i=0; i<checkboxName.length; i++) {
         if (checkboxName[i].checked) {
            retArr.length = lastElement;
            retArr[lastElement] = checkboxName[i].value;
            lastElement++;
         }
      }
	}else{// There is only one check box (it's not an array)
      if (checkboxName.checked) { // if the one check box is checked
         retArr.length = lastElement;
         retArr[lastElement] = checkboxName.value;
      }
   }
   return retArr;
}

//刪除確認
function deleteCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
	alert("沒有資料可以刪除!");
	}else{
	var frontName="document.";
	var checkboxArr=checkSelect(checkboxName);
	if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0)
	{
	alert("請勾選要刪除的資料！");
	}else{
	if(confirm('確定刪除資料?')){
	  eval(frontName+formName).submit();
	  }
	}
	}
}

//刪除確認
function newDeleteCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
	alert("沒有資料可以刪除!");
	}else{
	var frontName="document.";
	var checkboxArr=checkSelect(checkboxName);
	if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0)
	{
	alert("請勾選要刪除的資料！");
	}else{
	if(confirm('確定刪除資料?')){
	  eval(frontName+"getElementById('"+formName+"').submit()");
	  }
	}
	}
}

//刪除確認
function comfirmDelete(){
	if(confirm('確定刪除資料?')){
		return true;
	}
  	return false;
}

//manager delete confirm
function deleteManagerCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
		alert("沒有資料可以刪除!");
	}else{
		var frontName="document.";
		var checkboxArr=checkSelect(checkboxName);
		if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0)
		{
			alert("請勾選要刪除的資料！");
		}else{
			if(confirm('確定刪除資料?')){
				var urlStr = '';
				for(var i=0;i<checkboxArr.length;i++){
					urlStr+='&managerNo='
					urlStr+=checkboxArr[i];
				}
				var temp = document.getElementById(formName).action;
				document.getElementById(formName).action += urlStr;
				
				//alert(document.getElementById(formName).action);
	  			eval(frontName+"getElementById('"+formName+"')").submit();
	  			document.getElementById(formName).action = temp;
	  		}
		}
	}
}

//notify target delete confirm
function deleteTargetCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
		alert("沒有資料可以刪除!");
	}else{
		var frontName="document.";
		var checkboxArr=checkSelect(checkboxName);
		if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0)
		{
			alert("請勾選要刪除的資料！");
		}else{
			if(confirm('確定刪除資料?')){
				var urlStr = '';
				for(var i=0;i<checkboxArr.length;i++){
					urlStr+='&userIds='
					urlStr+=checkboxArr[i];
				}
				var temp = document.getElementById(formName).action;
				document.getElementById(formName).action += urlStr;
				
				//alert(document.getElementById(formName).action);
	  			eval(frontName+"getElementById('"+formName+"')").submit();
	  			document.getElementById(formName).action = temp;
	  		}
		}
	}
}

//刪除確認
function newUpdateStatusCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
	alert("沒有資料可以開放設定!");
	}else{
	var frontName="document.";
	var checkboxArr=checkSelect(checkboxName);
	if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0)
	{
	alert("請勾選要開放的資料！");
	}else{
	if(confirm('確定開放資料?')){
	  eval(frontName+"getElementById('"+formName+"')").submit();
	  }
	}
	}
}


//取消資格確認
function cancelCheck(checkboxName,formName){
	if(document.getElementsByName(checkboxName)==null){
	    alert("沒有資料可以取消資格!");
	}else{
        var frontName="document.";
        var checkboxArr=checkSelect(checkboxName);
        if(document.getElementsByName(checkboxName) == null||checkboxArr.length<=0) {
            alert("請勾選要取消資格的資料！");
        }else{
	        if(confirm('確定取消資料的資格?')){
	            eval(frontName+formName).submit();
            }
        }
    }
}

function selectAll( checkboxID,status )	{
	var input=document.getElementsByTagName("input");
	var inputNum=input.length;
	
	for(var i=0;i<inputNum;i++) {
		if(input.item(i).id=="")
		{
			if(input.item(i).name==checkboxID && input.item(i).disabled==false)
			{
				input.item(i).checked = status;
			}
		}
		else
		{
			if(input.item(i).id==checkboxID && input.item(i).disabled==false)
			{
				input.item(i).checked = status;
			}
		}
	}
	/*if( document.getElementsByName(checkboxID) == null)
		return;

	if( document.getElementsByName(checkboxID).length > 0 ){ 
		for(  i=0; i<document.getElementsByName(checkboxID).length; i++ )	{
		   if(!document.getElementsByName(checkboxID).item(i).disabled){
			document.getElementsByName(checkboxID).item(i).checked = status;
		    }
		}
	} else {
	   if(!document.getElementsByName(checkboxID).disabled){
		document.getElementsByName(checkboxID).checked = status;
		}
	}*/
}