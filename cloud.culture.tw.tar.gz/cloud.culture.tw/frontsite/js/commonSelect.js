var ajax = new Object();

ajax.io = new Object();

ajax.io.loadXML = function(url,load){

	var options = {method:"get",asynchronous:true,onSuccess:onsuccess,onFailure:function(){}};
	
	function onsuccess(http){
		
		load(http.responseXML);
	}
	
	ajax.io.sendRequest(url,options);
	
	
}



ajax.io.sendRequest = function (url,options,container){
	if(arguments.length==2){
		new Ajax.Request(url,options);
	}else if(arguments.length==3){
		new Ajax.Updater(container,url,options)
	}
}

ajax.io.submitForm = function (formNode,containerOrFunction){
	var sUrl = $('formNode').action;
	var options = {method:"post",asynchronous:true,onSuccess:containerOrFunction};
	options.postBody = Form.serialize($('formNode'));
	
	if(containerOrFunction instanceof Function){		
		ajax.io.sendRequest(sUrl,options);
	}else{
		new Ajax.Updater(container,sUrl,options)
	}	
}

Object.extend(Event, {
	fireEvent:function(/*element Id or it Self*/sElement,/*event Name ,eg. change */sEvent){
	if(document.all) {   
	          $(sElement).fireEvent('on'+sEvent);   
	 }else{   
	     var evt = document.createEvent('HTMLEvents');   
	     evt.initEvent(sEvent,true,true);   
	     $(sElement).dispatchEvent(evt);   
	  } 
	}
}
)

var SelectBase = Class.create();

SelectBase.prototype = {
	 initialize : function(){
	 },
	 init : function(sSelectId,sUrl){	 
	 	this.oSelect = $(sSelectId);
	 	this.top=null;
	 	this.changeUrl = sUrl;	 	
	 	this.currentOptionNum = this.oSelect.options.length	 	
	 	this.nextSelect = null;
	 	
	 	if(this.oSelect.options.length==0){
	 		this.oSelect.style.display='none';
	 	}
	 	
	 	Event.observe(this.oSelect,'change',this.onchange.bind(this),false)
	 },
	 
	 onchange : function(){

	  /**********************************************************/
	  	 //如果是单一模式
		if(this.top.single){
	  		var v = this.top.getLastSelectValue();	  		
			this.top.singleHidden.value = v||'';//返回下拉选框组的最后一个有效值
			Event.fireEvent(this.top.singleHidden,'change');//触发onchange事件，因为value设置不自动触发
			
		}
	   /**********************************************************/
	  
	 	var _select = this.oSelect;	 		 	
 		
 		if(_select.options.length!=0){/*Fix*/
 			_select.style.display='';
 		}else{
 			_select.style.display='none';
 		}
 		
	 	if(_select.selectedIndex <this.currentOptionNum&&this.nextSelect){//如果选回了当前默认选项	 		
	 		var s = this.nextSelect.oSelect;
	 		s.selectedIndex = this.nextSelect.currentOptionNum-1;
	 		/*删除options*/
	 		var len = s.length;
	 		var cm = this.nextSelect.currentOptionNum;
	 		while(len>cm){
	 			if(s.options.remove){//IE
	 				s.options.remove(len-1);
	 			}else{//Mozilla
	 				s.remove(len-1);
	 			}
	 			len--;
	 		}
	 		s.length = this.nextSelect.currentOptionNum;
	 		
	 		Event.fireEvent(this.nextSelect.oSelect,'change');//触发onchange事件，因为selectedIndex设置不自动触发
	 	}else if(this.changeUrl&&this.nextSelect){
	 		var url = this.changeUrl;
	 	
	 		var query = 'selectedValue='+this.oSelect.value+'&selectedName='+this.oSelect.name+'&formName='+this.oSelect.form.name+'&status=change';		 	
	 		url+= ((url.indexOf("?") > -1 ? "&" : "?") + query);
	 		
	 		ajax.io.loadXML(url,this._load.bind(this.nextSelect) );
	 	}
	 		
	 }
	 ,
	 
	 /**
	 	私有方法：加载服务器数据，并更新select
	 **/
	 _load : function(xml){
		
	 	try{
	 		var s = this.oSelect;	 		
	 		s.selectedIndex = this.currentOptionNum-1;
	 		/*删除options*/
	 		var len = s.length;
	 		var cm = this.currentOptionNum;	 		
	 		while(len>cm){
	 			if(s.options.remove){//IE
	 				s.options.remove(len-1);
	 			}else{//Mozilla
	 				s.remove(len-1);
	 			}
	 			len--;
	 		}
	 		s.length = this.currentOptionNum;	 		
		 			 	
		 	var entrys =  xml.documentElement.getElementsByTagName('entry');
		 	var count = entrys.length;
			
		 	for(var i=0;i<count;i++){
		 		var entry=  entrys[i];	 		 			
		 		var name = entry.getElementsByTagName('optionText')[0].firstChild.nodeValue;
		 		var value = entry.getElementsByTagName('optionValue')[0].firstChild.nodeValue;	 
		 		
	 			var oOption = new Option() ;
	 			oOption.text=name;
				oOption.value=value;
				
			  	this.oSelect.options.add(oOption);			  	
		 	}
		 	this.setCurentValue();
	 		
	 		if(this.oSelect.options.length!=0){/*Fix*/
 				this.oSelect.style.display='';
 		}
	 	}catch(e){alert('load exception : '+e.message)}
	 },
	 	 
	 setCurentValue : function(){		
	 	
	 	var currentValue = this.oSelect.getAttribute('cv',0);
	 	if(currentValue){
	 		var options = $A(this.oSelect.options);
	 		var count = options.length
	 		for(var i = 0;i<count;i++){
	 			if(currentValue == options[i].value){
	 				this.oSelect.selectedIndex = i;
	 				Event.fireEvent(this.oSelect,'change');//触发onchange事件，因为selectedIndex设置不自动触发
	 				break;
	 			}
	 		}
	 	}
	 	
	 	/**********************************************************/
	 	//如果是单一模式
		if(this.top.single){
		  	var v = this.top.getLastSelectValue();
			this.top.singleHidden.value = v||'';//返回下拉选框组的最后一个有效值
			Event.fireEvent(this.top.singleHidden,'change');//触发onchange事件，因为value设置不自动触发
		}
	   /**********************************************************/
	 },
	 addRelation : function(oSelectBase){
	 	oSelectBase.top = this.top;
	 	if(this.nextSelect){
	 		this.nextSelect.addRelation(oSelectBase);
	 	}else{
	 		this.nextSelect = oSelectBase;
	 	}
	 },
	 getLastSelectValue:function(){	 
	 	var sel = this.oSelect;	 	
	 	if(this.nextSelect){
	 		var result = this.nextSelect.getLastSelectValue();
	 	}
	 	if(result!=undefined){
	 		return result;
	 	}else if(sel.selectedIndex>=this.currentOptionNum){
	 		return sel.value;
	 	}
	 }
	 
}

/**
url 会自动添加如下参数
formName 		表单的NAME
selectedName	列表框的NAME
selectedValue	列表框的VALUE
status			状态load or change
**/

var SelectBind = Class.create();

SelectBind.prototype = Object.extend(new SelectBase(),{
	
	 initialize : function(sSelectId,/*url*/sLoadUrl,/* change url,不必填，则同sLoadUrl*/sChangeUrl){	
	 	 this.loadUrl = sLoadUrl;
	 	 this.init(sSelectId,sChangeUrl||sLoadUrl);
	 	 this.top = this;
	 	 if($(sSelectId).form){
	 	 	$(sSelectId).form.selectUrl = sChangeUrl||sLoadUrl;
	 	 }
	 },
	load : function(){
	
		//如果是单一模式
		if(this.single){			
			var name = this.single.name;
			var fillSelects = this.single.fillSelects;
			
			this.singleHidden = $(name);
			/*
			var onsubmit = function(){
				
				var v = this.getLastSelectValue();
				this.singleHidden.value = v||'';//返回下拉选框组的最后一个有效值				
			}
			Event.observe(this.oSelect.form,'submit',onsubmit.bind(this),false);
			*/
			/*
				如果单一值的Hidden里有存在值,调用CallBack 函数 fillSelects(value),
				e.g 	var action = 'associate.xml';	
						var sb = new SelectBind('leave1',action);
						sb.fillSelects = function (value){
							//....
						}
			*/
			if(this.singleHidden.value&&fillSelects){
				fillSelects(this.singleHidden.value);
			}
		}
			
		var url = this.loadUrl;
		
	 	if(url){	 
	 		
	 		var query = 'selectedValue='+this.oSelect.value+'&selectedName='+this.oSelect.name+'&formName='+this.oSelect.form.name+'&status=load';;		 	
	 		url+= ((url.indexOf("?") > -1 ? "&" : "?") + query);	
	 		 	
	 		ajax.io.loadXML(url,this._load.bind(this) );
	 	}
	 }
}
);


var AssociateSelect = Class.create();

AssociateSelect.prototype = Object.extend(new SelectBase(),{
	 initialize : function(sSelectId,/*change url*/sChangeUrl){	 
	 	var surl = $(sSelectId).form ?$(sSelectId).form.selectUrl:null;
	 	 this.init(sSelectId,sChangeUrl||surl);
	 }
}
);

/****************************util*************************************/
