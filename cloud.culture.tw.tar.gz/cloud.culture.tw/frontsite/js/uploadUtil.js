/*********************************************/
/*these methods can be used in firefox and ie*/
/*********************************************/


	
	var UploadUtil = function (settings) {
		this.url=settings['url'];
//		this.index=settings['index'];
		this.showx=settings['showx'];
		this.showy=settings['showy'];
		this.isLoading=settings['isLoading'];
		this.parentwindow=settings['parentwindow'];
		this.p=settings['p'];
		this.fileNameInServer=settings['fileNameInServer'];
		this.showPath=settings['showPath'];
		this.dialog_page=settings['dialog_page'];
		this.dialog_noLoading_page=settings['dialog_noLoading_page'];
//		this.open_root=settings['open_root'];
		this.isMSIE=settings['isMSIE'];		
	};
	UploadUtil.prototype.doUpload = function (width,height) {
	
		var result = this.openModeWindow(width,height);
		
        if (this.isMSIE) {  

			if(result){
				var file = result['file'];
				var path = result['path'];
//				$(this.fileNameInServer).value= file;
//				$(this.showPath).value = path;
				var fileNameInServers=this.fileNameInServer.split(';');
				if(fileNameInServers.length==0){
					$(this.fileNameInServer).value = file;
					
				}else{
					for(var i=0;i<fileNameInServers.length;i++){
						$(fileNameInServers[i]).value = file;
					}
				}
				var showPaths=this.showPath.split(';');
				if(showPaths.length==0){
					$(this.showPath).value = path;
				}else{
					for(var i=0;i<showPaths.length;i++){
						$(showPaths[i]).value = path;
					}
				}
				
//				if(this.index){
//					$('_fileNameInServer_'+this.index).value= file;
//					$('_showPath_'+this.index).value = path;
//				}else{
//					$('_fileNameInServer').value= file;
//					$('_showPath').value = path;
//				}

			}
		}
	}
	
	
	
	UploadUtil.prototype.openModeWindow = function (width,height) {	
		var div;
		if (this.isMSIE) {  
	   		 if(navigator.userAgent.indexOf("MSIE 9.0")>0) {
	   			 div = document.createElement("div");
	   			 div.setAttribute("style","position: absolute;z-index: 200;top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;filter: alpha(opacity=40);background: lightgrey;");
	   	     }else{
	   	    	 div = document.createElement('<div style="position: absolute;'+
	   	 				'top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;'+
	   	 				'+filter: alpha(opacity=40);'+
	   	 				'background: lightgrey;" />');
	   	     }
		}else{
			div = document.createElement("div");
			div.setAttribute("style","position: absolute;z-index: 200;top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;filter: alpha(opacity=40);background: lightgrey;");
		
		}
		if(document.body){
			
			this.ourdiv = document.body.appendChild(div);
		}
		var value = this.popWindow(width,height);
		if(!this.isMSIE){  
			
        	div.addEventListener("click",function(){
        	//	window.blur();
				retval.focus();
        	},false);
        	
	        window.onfocus = function(){
				window.blur();
				result.focus();
			}    
		}
   		if (this.isMSIE) { 
			if(document.body){
				document.body.removeChild(this.ourdiv);
			}
		}
		return value;
		
//		function reSet(result){
//			if(result){
//				var file = result['file'];
//				var path = result['path'];
//				$(this.fileNameInServer).value= file;
//				$(this.showPath).value = path;
//				if(this.index){
//					$('_fileNameInServer_'+index).value= file;
//					$('_showPath_'+index).value = path;
//				}else{
//					$('_fileNameInServer').value= file;
//					$('_showPath').value = path;
//				}

//			}
//		}
	}
	UploadUtil.prototype.popWindow = function(width,height){		
			var par = []; 
			par['url'] = this.url;
			par['parentwindow'] = this.parentwindow;
			par['p']=this.p;	
			var dialog =this.dialog_page;
			if(false==this.isLoading){
			   dialog=this.dialog_noLoading_page;
			}
			
		   	var s1 = "dialogWidth:"+width+"px; dialogHeight:"+height+"px; dialogLeft:"+this.showx+"px; dialogTop:"+
		   			this.showy+"px;  help:no;directories:yes;scrollbars:no;Resizable=no;status:no;";		   
        	if (this.isMSIE) {  
			    retval = window.showModalDialog(dialog,		    
			    par,s1
			    );
			}else{
				s1 = "width="+width+"px, height="+height+"px, left="+this.showx+"px, top="+
		   			this.showy+"px,  help=no,directories=yes,scrollbars=no,Resizable=no,status=no,modal=yes";
				window.myAction=this;		

				retval =window.open(dialog,"",s1);
				retval.onbeforeunload=function(){
					window.onfocus = function(){}					
					window.focus();
				}
				window.myArguments=par;
				this.returnAction=function(result){		
					if(document.body){
						document.body.removeChild(this.ourdiv);
					}				
					if(typeof(result) != undefined){
						retval=result;
					    this.reSet(retval);
					}
					
				}
			}
			return retval;
		}
	UploadUtil.prototype.reSet = function (result) {
	
		if(result){
			var file = result['file'];
			var path = result['path'];
//			$(this.fileNameInServer).value= file;
//			$(this.showPath).value = path;
			var fileNameInServers=this.fileNameInServer.split(';');
			if(fileNameInServers.length==0){
				$(this.fileNameInServer).value = file;
					
			}else{
				for(var i=0;i<fileNameInServers.length;i++){
					$(fileNameInServers[i]).value = file;
				}
			}
			var showPaths=this.showPath.split(';');
			if(showPaths.length==0){
				$(this.showPath).value = path;
			}else{
				for(var i=0;i<showPaths.length;i++){
					$(showPaths[i]).value = path;
				}
			}
//			if(this.index){
//				$('_fileNameInServer_'+index).value= file;
//				$('_showPath_'+index).value = path;
//			}else{
//				$('_fileNameInServer').value= file;
//				$('_showPath').value = path;
//			}

		}
	}
	/****************************************************************/
	
	UploadUtil.prototype.doHtmlEditUpload = function (width,height,n) {
		var result = this.openHtmlEditModeWindow(width,height,n);
		return result;
	}
	
	
	
	UploadUtil.prototype.openHtmlEditModeWindow = function (width,height,n) {	
		
		var div;
	    	if (this.isMSIE) {  
			div = document.createElement('<div style="position: absolute;'+
				'top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;'+
				'+filter: alpha(opacity=40);'+
				'background: lightgrey;" />');
			
		}else{
			div = document.createElement("div");
			div.setAttribute("style","position: absolute;z-index: 200;top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;filter: alpha(opacity=40);background: lightgrey;");
		}
		if(document.body){
			this.ourdiv = document.body.appendChild(div);
		}
		var value = this.popHtmlEditWindow(width,height,n);
   		if (this.isMSIE) { 
			if(document.body){
				document.body.removeChild(this.ourdiv);
			}
		}

		return value;
		
//		function reSet(result){
//			if(result){
//				var file = result['file'];
//				var path = result['path'];
//				$(this.fileNameInServer).value= file;
//				$(this.showPath).value = path;
//				if(this.index){
//					$('_fileNameInServer_'+index).value= file;
//					$('_showPath_'+index).value = path;
//				}else{
//					$('_fileNameInServer').value= file;
//					$('_showPath').value = path;
//				}

//			}
//		}
	}
	UploadUtil.prototype.popHtmlEditWindow = function(width,height,n){		
			
			var par = []; 
			par['url'] = this.url;
			par['parentwindow'] = this.parentwindow;
			par['p']=this.p;	
			var dialog =this.dialog_page;
			if(false==this.isLoading){
			   dialog=this.dialog_noLoading_page;
			}
			
		   	var s1 = "dialogWidth:"+width+"px; dialogHeight:"+height+"px; dialogLeft:"+this.showx+"px; dialogTop:"+
		   			this.showy+"px;  help:no;directories:yes;scrollbars:no;Resizable=no;status:no;";		   
        	if (this.isMSIE) {  
			    retval = window.showModalDialog(dialog,		    
			    par,s1
			    );
			}
			else{
				s1 = "width="+width+"px, height="+height+"px, left="+this.showx+"px, top="+
		   			this.showy+"px,  help=no,directories=yes,scrollbars=no,Resizable=no,status=no,modal=yes";
				window.myAction=this;
				window.myArguments = par;
				dialogWin =window.open(dialog,"",s1);
				this.returnAction=function(result){		
					if(document.body){
						document.body.removeChild(this.ourdiv);
					}				
							
					if(typeof(result) != undefined){
						
						retval=result;
						this.htmlEditReSet(retval,n);
					}
					
				}
			}
			
			return retval;
		}
	UploadUtil.prototype.htmlEditReSet = function (result,n) {
		if(result){
			var file = result['file'];
			var path = result['path'];	
		 	var image = '<img alt="'+file+'" src="'+ path + '" title="'+file+'">';
			insertImageHTML(image,n);
			//insertHTML(image,n);
			
//			if(this.index){
//				$('_fileNameInServer_'+index).value= file;
//				$('_showPath_'+index).value = path;
//			}else{
//				$('_fileNameInServer').value= file;
//				$('_showPath').value = path;
//			}

		}
	}
	
	
	
	/*function doUpload(type,index){

		var result = openModeWindow('hakka/backendadmin/template/uploadDialog.jsp?moudel='+type,500,435);
		var isMSIE= (navigator.appName == "Microsoft Internet Explorer");  

        if (isMSIE) {  

			if(result){
				var file = result['file'];
				var path = result['path'];
				if(index){
					$('_fileNameInServer_'+index).value= file;
					$('_showPath_'+index).value = path;
				}else{
					$('_fileNameInServer').value= file;
					$('_showPath').value = path;
				}

			}
		}else{
			gindex=index;
		}
	}
function openModeWindow(url,width,height,isLoading,p){

		function popWindow(url,width,height){
		    showx = (screen.availWidth -width)/2; // + deltaX;
		    showy = (screen.availHeight-height)/2; // + deltaY;
			var par = []; 
			par['url'] = url;
			par['parentwindow'] = window;
			par['p']=p;
         
		   	var s1 = "dialogWidth:"+width+"px; dialogHeight:"+height+"px; dialogLeft:"+showx+"px; dialogTop:"+
		   			showy+"px;  help:no;directories:yes;scrollbars:no;Resizable=no;status:no;";
		   	var dialog ='dialog.jsp';
		   	if(false==isLoading){
		   		dialog='dialog_noLoading.jsp';
		   	}

	 		var isMSIE= (navigator.appName == "Microsoft Internet Explorer");  

        	if (isMSIE) {  
			    retval = window.showModalDialog('hakka/backendadmin/template/'+dialog,		    
			    par,s1
			    );
			}else{
				s1=s1+"modal=yes";
				window.myAction=this;
				dialogWin =window.open('hakka/backendadmin/template/'+dialog,"",s1);
				window.myArguments=par;
				this.returnAction=function(result){
					
					
					if(typeof(result) != undefined){

						retval=result;
						reSet(retval);
					}

				}
			}
			return retval;
		}

		var value = popWindow(url,width,height);
		var isMSIE= (navigator.appName == "Microsoft Internet Explorer");  
        if (isMSIE) {  
			var div = document.createElement('<div style="position: absolute;z-index: 200;'+
				'top: 0px;left: 0px;width: 1280px;height: 1024px;opacity: .4;'+
				'+filter: alpha(opacity=40);background-color:transparent !important;'+
				'background-color: lightgrey;" />');
			if(document.body){
				var ourdiv = document.body.appendChild(div);
			}
		
		
			if(document.body){
				document.body.removeChild(ourdiv);
			}
		}

		return value;
		
	}	
	function reSet(result,gindex){
			if(result){
				var file = result['file'];
				var path = result['path'];
				if(gindex){
					$('_fileNameInServer_'+index).value= file;
					$('_showPath_'+index).value = path;
				}else{
					$('_fileNameInServer').value= file;
					$('_showPath').value = path;
				}

			}
	}*/
	
	