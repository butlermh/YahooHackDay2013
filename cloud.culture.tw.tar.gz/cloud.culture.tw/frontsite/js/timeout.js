var pendingMessages = new Array();
var syncTimer = null;
var timeoutTimer = null;

ajaxCaller.shouldDebug = false;
ajaxCaller.shouldMakeHeaderMap = false;

/**
 *	session time = 60 minute = 59+1 minute
 *  we will leave 10 sec to user, so we need 59*60 sec + 50 sec
 */
var ALERT_TIME = (17*60+50)*1000;
//var ALERT_TIME = 3000;
//var TIMEOUT_TIME = 6000;

//Event.observe(window,'load',timeout,false)

//timeout = function() {
// alertTimer = setTimeout(onTimealert,ALERT_TIME);
//}
/**
function onMessagesLoaded(text, callingContext) {
  window.status = "loaded";
  //alert(text);
  try{
  if(text.length>50){
  	$('s_pwd').innerText = "session is time out!";
  }else{
  	$('s_pwd').innerText = "pwd:"+text;
  	clearTimeout(alertTimer);
  	alertTimer = setTimeout(onTimealert,ALERT_TIME);
  }}catch(e){alert(e.message);}
}**/

function synchronise() {
  ajaxCaller.getPlainText("/backendadmin/loginAction.do?method=doNothing", onMessagesLoaded);
  return;
}

function onTimealert() {
  var returnValue=window.showModalDialog("../template/timeoutDialog.jsp",window,"dialogHeight:260px;dialogWidth:510px;center:yes");
  //var returnValue = window.open('../template/timeoutDialog.jsp',null,"height=260,width=510,status=yes,toolbar=no,menubar=no,location=no,top=400,left=400");
  if(returnValue == true){//
  		alertTimer = setTimeout(onTimealert,ALERT_TIME);
  }else {
  		onTimeout();
  }
}

function doMaintain(){
	alertTimer = setTimeout(onTimealert,ALERT_TIME);
}

function onTimeout() {
  window.location = contextPath+'/backendadmin/login_tour.jsp';
}

function doNothing(text, callingContext){
	return ;
}

function doRemoveSession() {
	ajaxCaller.getPlainText("/backendadmin/loginAction.do?method=doRemoveSession", doNothing);
}