
//????\uFFFD??\uFFFD


function PopCalendarL(objname,url)
{  
    var retval
    showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
    showy = event.screenY - event.offsetY -168; // + deltaY;
    newWINwidth = 210 + 4 + 18;
    url=url+'/backendadmin/js/Calendar.htm';
    retval = window.showModalDialog(url, "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
    if( retval != null ){
        document.all(objname).value = retval;
    }else{
    //alert("canceled");
    }
}

function PopCalendar(objname,evt)
{
    if(document.all){
        var retval;
        showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
        showy = event.screenY - event.offsetY -168; // + deltaY;
        newWINwidth = 210 + 4 + 18;
        retval = window.showModalDialog("../js/Calendar.jsp?date="+document.getElementsByName(objname)[0].value, "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
        if( retval != null ){
            document.all(objname).value = retval;
        }else{
        //alert("canceled");
        }
        
    	try{
    		//複合查詢用
    		dateChange(null);
    	}catch(err){
    		//Handle errors here
    		//alert('err');
    	}
		
    }else{
		
        var retval;
        //showx = evt.screenX - evt.offsetX - 4 - 10 ; // + deltaX;
        // showy = evt.screenY - evt.offsetY -168; // + deltaY;
        newWINwidth = 210 + 4 + 18;
        showx = (screen.availWidth -197)/2; // + deltaX;
        showy = (screen.availHeight-230)/2; // + deltaY;
        window.myAction=this;
			    
        this.returnAction=function(result){
            if( result != null ){
                if(document.getElementsByName(objname).length!=0)
                {
                    document.getElementsByName(objname)[0].value = result;
                }
                else
                {
                    document.getElementById(objname).value = result;
                }
            }else{
            //alert("canceled");
            }
            
        	try{
        		//複合查詢用
        		dateChange(null);
        	}catch(err){
        		//Handle errors here
        		//alert('err');
        	}
				
        }
        //firefox跟chrome無法使用document.getelementByNames(xxx)[0].value			    
        retval = window.open("../js/Calendar.jsp?date="+document.getElementById(objname).value, "", "modal=yes,width=207,height=230,left="+showx+",top="+showy+",status=no,directories=yes,scrollbars=no,Resizable=no"  );
	   
				
				
    //alert('retval.value='+retval.value);
    // if( retval != null ){
    //     document.getElementsByName(objname).value = result;
    // }else{
    //alert("canceled");
    // }
		
		
    }
	
}

function PopCalendarBrithday(objname,evt)
{

    if(document.all){
        var retval;
        showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
        showy = event.screenY - event.offsetY -168; // + deltaY;
        newWINwidth = 210 + 4 + 18;
        retval = window.showModalDialog("../js/calendarforBrith.jsp?date="+document.getElementsByName(objname)[0].value, "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
        if( retval != null ){
            document.all(objname).value = retval;
        }else{
        //alert("canceled");
        }
		
    }else{
		
        var retval;
        //showx = evt.screenX - evt.offsetX - 4 - 10 ; // + deltaX;
        // showy = evt.screenY - evt.offsetY -168; // + deltaY;
        newWINwidth = 210 + 4 + 18;
        showx = (screen.availWidth -197)/2; // + deltaX;
        showy = (screen.availHeight-230)/2; // + deltaY;
        window.myAction=this;
			    
        this.returnAction=function(result){
            if( result != null ){
                if(document.getElementsByName(objname).length!=0)
                {
                    document.getElementsByName(objname)[0].value = result;
                }
                else
                {
                    document.getElementById(objname).value = result;
                }
            }else{
            //alert("canceled");
            }
				
        }
        retval = window.open("../js/calendarforBrith.jsp?date="+document.getElementsByName(objname)[0].value, "", "modal=yes,width=197,height=230,left="+showx+",top="+showy+",status=no,directories=yes,scrollbars=no,Resizable=no"  );
				
				
				
				
    //alert('retval.value='+retval.value);
    // if( retval != null ){
    //     document.getElementsByName(objname).value = result;
    // }else{
    //alert("canceled");
    // }
		
		
    }
	
}

function PopCalendarId(objid)
{

    var retval
    showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
    showy = event.screenY - event.offsetY -168; // + deltaY;
    newWINwidth = 210 + 4 + 18;
    retval = window.showModalDialog("../js/Calendar.htm", "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
    
    if( retval != null ){
        document.getElementById(objid).value = retval;
    }else{
    //alert("canceled");
    }
}

function PopCalendarIdforAdd(objid,num)
{

    //alert(objid);
    //alert(num);
    var retval
    showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
    showy = event.screenY - event.offsetY -168; // + deltaY;
    newWINwidth = 210 + 4 + 18;
    retval = window.showModalDialog("../js/Calendar.htm", "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
    var returnId = objid+num;
    if( retval != null ){
        document.getElementById(returnId).value = retval;
    }else{
    //alert("canceled");
    }
}

//????\uFFFD??\uFFFD
function PopCalendar2(objname)
{

    var retval
    showx = event.screenX - event.offsetX - 4 - 10 ; // + deltaX;
    showy = event.screenY - event.offsetY -168; // + deltaY;
    newWINwidth = 210 + 4 + 18;
    retval = window.showModalDialog("../js/Calendar2.jsp", "", "dialogWidth:197px; dialogHeight:230px; dialogLeft:"+showx+"px; dialogTop:"+showy+"px; status:no; directories:yes;scrollbars:no;Resizable=no; "  );
    if( retval != null ){
        document.all(objname).value = retval;
    }else{
    //alert("canceled");
    }
}
//if (return true) {no error happen} else {format error}
function Check_Date(date_value)
{
    var date_error=false;
    var dayslist=new Array(31,28,31,30,31,30,31,31,30,31,30,31);
    var years,month;
    if (date_value.length!=10)
    {
        date_error=true;
    }
    else
    {
        if (!isNum(date_value.substring(0,4)) || (parseInt(date_value.substring(0,4),10)>2999) || (parseInt(date_value.substring(0,4),10)<1900))
        {
            date_error=true;
        }
        else
        {
            years=parseInt(date_value.substring(0,4));
            if (years%4==0&&years%100!=0)
            {
                dayslist[1]=29;
            }
        }
    }

    if (!date_error)
    {
        if (!isNum(date_value.substring(5,7)) || (parseInt(date_value.substring(5,7),10)<1)  || (parseInt(date_value.substring(5,7),10)>12))
        {
            date_error=true;
        }
        else
        {
            month=parseInt(date_value.substring(5,7),10);
        }
    }

    if (!date_error)
    {
        if ((!isNum(date_value.substring(8,10)) || (parseInt(date_value.substring(8,10),10)<1) || (parseInt(date_value.substring(8,10),10)>31)))
        {
            date_error=true;
        }
        else
        {

            if (parseInt(date_value.substring(8,10))>dayslist[month-1])
            {
                date_error=true;
            }
        }
    }

    if (!date_error)
    {
        if ((date_value.substr(4,1)!='-')  || (date_value.substr(7,1)!='-'))
        {
            date_error=true;
        }
    }
    if (date_error)
    {
        return false;
    }
    else
    {
        return true;
    }
} // check some date format to fit for '2000-02-09' format



function isNum(str_num) {
    for (var i=0; i < str_num.length; i++) {
        num = parseInt(str_num.substring(i,i+1));
        if (isNaN(num)){
            return false;
        }
    }
    return true;
}  //end function


function trimstr(str)
{
    var i=0;
    var len=str.length
    j=len-1;
    flagbegin=true;
    flagend=true;
    if (str!="")
    {
        while (flagbegin==true)
        {
            if (str.charAt(i)==" ")
            {
                i=i+1;
                flagbegin=true;
            }
            else
            {
                flagbegin=false;
            }
        }
        while (flagend==true)
        {
            if (str.charAt(j)==" ")
            {
                j=j-1;
                flagend=true;
            }
            else
            {
                flagend=false;
            }
        }
        if (i>j)
        {
            return("");
        }
        else
        {
            return (str.substring(i,j+1))  ;
        }
    }
    else
    {
        return(str);
    }
}


function isFloat(strfloat)
{
    if(strfloat!="")
    //alert("strfloat");
    {
        if (isNaN(parseFloat(strfloat)))
        {
            // alert("??????\uFFFD??\uFFFD?? ")
            return(false);
        }
        else
        {
            if (trimstr(strfloat)!=parseFloat(strfloat))
            {
                //  alert("?????????? ")
                return(false);
            }
            else
            {
                return(true);
            }
        }
    }
    else
    {
        return(true)
    }
}

function digit(obj)
{
    if (document.all(obj).value!="")
    {
        if(!isFloat(document.all(obj).value))
        {
            document.all(obj).select()
            return(false)

        }
    }

}

function compare_date(date1,date2,alertstr)
{
    if (document.all(date2).value!="")
    {
        if (document.all(date1).value>document.all(date2).value)
        {
            alert(alertstr)
            return (false)
        }
        else
        {
            return(true)
        }
    }
    else
    {
        return(true)
    }
}

function replacestr(sStr)
{
    var tempstr
    tempstr=sStr
    while (tempstr.indexOf("\"")!=-1 )
    {
        tempstr=tempstr.replace("\"","&quot;");
    }
    return(tempstr)
}

function FormatNum(Fnum,digdec)
{
    var tempNum
    var i
    var mulc=1
    for (i=1;i<=digdec;i++)
        mulc=mulc*10
    tempNum=Math.round(parseFloat(Fnum)*parseFloat(mulc))/parseFloat(mulc)
    return (tempNum)
}

