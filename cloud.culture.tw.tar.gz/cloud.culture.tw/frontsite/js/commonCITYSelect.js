
function singleCity(id,contextpath){
	var action = contextpath+'/citySelectXMLAction.do';
	new SelectBind(id,action).load();
}



function towCity(contextpath,city,block,valueId_){
	
	var id1=city||'city',id2=block||'block',valueId=valueId_||'cityValue';
	document.getElementById(id1).style.width='auto';
	document.getElementById(id2).style.width='auto';

	var action = contextpath+'/citySelectXMLAction.do';
	
	var sb = new SelectBind(id1,action);
	sb.addRelation(new AssociateSelect(id2));		
	sb.single = {name:valueId,fillSelects:fillSelectsImpl}	
	
	sb.load();
	
	function fillSelectsImpl(value){
		if(value){
			
			var length = value.length;	
			
			if(length<=2){				
				document.getElementById(id1).setAttribute('cv',value);
			}else if(length==3){
				document.getElementById(id1).setAttribute('cv',value.substring(0,1))
				document.getElementById(id2).setAttribute('cv',value)	
			}else{//length==4
				
				document.getElementById(id1).setAttribute('cv',value.substring(0,2))					
				document.getElementById(id2).setAttribute('cv',value)	
			}
		}	
	}
}

function towCNCity(contextpath,city,block,valueId_){
	
	var id1=city||'city',id2=block||'block',valueId=valueId_||'cityValue';
	document.getElementById(id1).style.width='80px';
	document.getElementById(id2).style.width='80px';

	var action = contextpath+'/cnCitySelectXMLAction.do';
	
	var sb = new SelectBind(id1,action);
	sb.addRelation(new AssociateSelect(id2));		
	sb.single = {name:valueId,fillSelects:fillSelectsImpl}	
	
	sb.load();
	
	function fillSelectsImpl(value){
		if(value){
			
			var length = value.length;	
			
			if(length<=2){				
				document.getElementById(id1).setAttribute('cv',value);
			}else if(length==3){
				document.getElementById(id1).setAttribute('cv',value.substring(0,1))
				document.getElementById(id2).setAttribute('cv',value)	
			}else{//length==4
				
				document.getElementById(id1).setAttribute('cv',value.substring(0,2))					
				document.getElementById(id2).setAttribute('cv',value)	
			}
		}	
	}
}

function towQuanXianCity(contextpath,city,block,valueId_){
	
	var id1=city||'city',id2=block||'block',valueId=valueId_||'cityValue';
	document.getElementById(id1).style.width='80px';
	document.getElementById(id2).style.width='80px';

	var action = contextpath+'/citySelectXMLAction.do?xuanqian=true';
	
	var sb = new SelectBind(id1,action);
	sb.addRelation(new AssociateSelect(id2));		
	sb.single = {name:valueId,fillSelects:fillSelectsImpl}	
	
	sb.load();
	
	function fillSelectsImpl(value){
		if(value){
			
			var length = value.length;	
			
			if(length<=2){				
				document.getElementById(id1).cv=value;
			}else if(length==3){
				document.getElementById(id1).setAttribute('cv',value.substring(0,1))
				document.getElementById(id2).setAttribute('cv',value)	
			}else{//length==4
				
				document.getElementById(id1).setAttribute('cv',value.substring(0,2))					
				document.getElementById(id2).setAttribute('cv',value)	
			}
		}	
	}
}

