
function showFileName(path){
	var index = path.lastIndexOf('/')+1;
	var p = path.substring(index,path.length);
	document.write(p);
}
