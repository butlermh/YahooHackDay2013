
// Provide a default path to dwr.engine
if (dwr == null) var dwr = {};
if (dwr.engine == null) dwr.engine = {};
if (DWREngine == null) var DWREngine = dwr.engine;

if (assetsMapPhotoWallAction == null) var assetsMapPhotoWallAction = {};
assetsMapPhotoWallAction._path = '/dwr';
assetsMapPhotoWallAction.doSearch = function(p0, p1, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'doSearch', p0, p1, false, false, callback);
}
assetsMapPhotoWallAction.doLoadPhotoWall = function(p0, p1, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'doLoadPhotoWall', p0, p1, false, false, callback);
}
assetsMapPhotoWallAction.doLoadPhotoWall2 = function(p0, p1, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'doLoadPhotoWall2', p0, p1, false, false, callback);
}
assetsMapPhotoWallAction.doSearch2 = function(p0, p1, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'doSearch2', p0, p1, false, false, callback);
}
assetsMapPhotoWallAction.setCouldReset = function(callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'setCouldReset', false, callback);
}
assetsMapPhotoWallAction.execute = function(p0, p1, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'execute', p0, p1, false, false, callback);
}
assetsMapPhotoWallAction.execute = function(p0, p1, p2, p3, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'execute', p0, p1, p2, p3, callback);
}
assetsMapPhotoWallAction.getServlet = function(callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'getServlet', callback);
}
assetsMapPhotoWallAction.setServlet = function(p0, callback) {
  dwr.engine._execute(assetsMapPhotoWallAction._path, 'assetsMapPhotoWallAction', 'setServlet', p0, callback);
}
