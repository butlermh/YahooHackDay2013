/**
 * �@�������js
 */
$(document).ready(function(){
	$.datepicker.regional['zh-TW'] = {

		showMonthAfterYear : false,
		changeMonth : true,
		changeYear : true,
		isRTL : false,
		showButtonPanel : true,
		dateFormat: 'yy/mm/dd',
		yearRange : '2010:2015',
		showAnim : ''

	};
	$.datepicker.setDefaults($.datepicker.regional['zh-TW']);

});